<script type="text/javascript">
      jQuery(document).ready(function($) {
            $('.datatable').DataTable();
      });

      $(document).ready(function() {
          $('.select2').select2();
      });
</script>
